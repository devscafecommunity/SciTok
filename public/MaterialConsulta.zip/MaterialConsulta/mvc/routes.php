<?php

    return [
        'defaultRoute' => ['GET', 'HomeController', 'index'],
        'home' => [
            'index' => ['GET', 'HomeController', 'index'],
        ]
        // rota, ação, método HTTP, controlador, view
    ];