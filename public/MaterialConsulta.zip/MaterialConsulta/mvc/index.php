<?php
    require_once 'startup/config.php';
    require_once 'framework/Router.php';
    $router = new Router();
    $router->route();